/*******************************************************************/
/*                                                                 */
/* Copyright 2007 Adobe                                            */
/* All Rights Reserved.                                            */
/*                                                                 */
/* NOTICE:  Adobe permits you to use, modify, and distribute this  */
/* file in accordance with the terms of the Adobe license          */
/* agreement accompanying it.                                      */
/*                                                                 */
/*******************************************************************/

#ifndef AEFX_SND_Stuff_DECL
#define AEFX_SND_Stuff_DECL

#include "AE_Effect.h"

#include <cmath>

#ifdef DEBUG
    #define AEFX_INLINE static
#else

    #ifdef AE_OS_WIN
        #define AEFX_INLINE static _inline
    #else
        #define AEFX_INLINE static inline
    #endif

#endif

#define AEFX_ROUNDDBL(X) std::lround(X)

#define AEFX_TypeFto8(TYPE) (char)AEFX_ROUNDDBL((TYPE)*127.0)
#define AEFX_TypeFto16(TYPE) (short)AEFX_ROUNDDBL((TYPE)*32767.0)
#define AEFX_Type8toF(TYPE) ((TYPE) / 128.0)
#define AEFX_Type16toF(TYPE) ((TYPE) / 32768.0)

#define AEFX_8_SIGNED_MAX ((char)0x7F)
#define AEFX_8_SIGNED_MIN ((char)0x80)
#define AEFX_16_SIGNED_MAX ((short)0x7FFF)
#define AEFX_16_SIGNED_MIN ((short)0x8000)
#define AEFX_FLOAT_SIGNED_MAX ((float)1.0)
#define AEFX_FLOAT_SIGNED_MIN ((float)-1.0)

#define AEFX_CLIP_8_SIGNED(VALUE)                                                                                      \
    if ((VALUE) > AEFX_8_SIGNED_MAX)                                                                                   \
        (VALUE) = AEFX_8_SIGNED_MAX;                                                                                   \
    else if ((VALUE) < AEFX_8_SIGNED_MIN)                                                                              \
    (VALUE) = AEFX_8_SIGNED_MIN

#define AEFX_CLIP_16_SIGNED(VALUE)                                                                                     \
    if ((VALUE) > AEFX_16_SIGNED_MAX)                                                                                  \
        (VALUE) = AEFX_16_SIGNED_MAX;                                                                                  \
    else if ((VALUE) < AEFX_16_SIGNED_MIN)                                                                             \
    (VALUE) = AEFX_16_SIGNED_MIN

#define AEFX_CLIP_FLOAT_SIGNED(VALUE)                                                                                  \
    if ((VALUE) > AEFX_FLOAT_SIGNED_MAX)                                                                               \
        (VALUE) = AEFX_FLOAT_SIGNED_MAX;                                                                               \
    else if ((VALUE) < AEFX_FLOAT_SIGNED_MIN)                                                                          \
    (VALUE) = AEFX_FLOAT_SIGNED_MIN

#endif //AEFX_SND_Stuff_DECL