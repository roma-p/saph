/*******************************************************************/
/*                                                                 */
/* Copyright 2025 Adobe                                            */
/* All Rights Reserved.                                            */
/*                                                                 */
/* NOTICE:  Adobe permits you to use, modify, and distribute this  */
/* file in accordance with the terms of the Adobe license          */
/* agreement accompanying it.                                      */
/*                                                                 */
/*******************************************************************/

/* Portable_Strings.h */

#pragma once

typedef enum
{
    StrID_NONE,
    StrID_Name,
    StrID_Description,
    StrID_Slider_Param_Name,
    StrID_Color_Param_Name,
    StrID_Float_Param_Name,
    StrID_Angle_Param_Name,
    StrID_Null_Param_Name,
    StrID_Popup_Param_Name,
    StrID_Popup_Choices,
    StrID_Checkbox_Param_Name,
    StrID_Checkbox_Description,
    StrID_DependString1,
    StrID_DependString2,
    StrID_Err_LoadSuite,
    StrID_Err_FreeSuite,
    StrID_NUMTYPES
} StrIDType;
