/*******************************************************************/
/*                                                                 */
/* Copyright 2025 Adobe                                            */
/* All Rights Reserved.                                            */
/*                                                                 */
/* NOTICE:  Adobe permits you to use, modify, and distribute this  */
/* file in accordance with the terms of the Adobe license          */
/* agreement accompanying it.                                      */
/*                                                                 */
/*******************************************************************/

//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Custom_ECW_UIPiPL.rc
//

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
    #ifndef APSTUDIO_READONLY_SYMBOLS
        #define _APS_NEXT_RESOURCE_VALUE 101
        #define _APS_NEXT_COMMAND_VALUE 40001
        #define _APS_NEXT_CONTROL_VALUE 1000
        #define _APS_NEXT_SYMED_VALUE 101
    #endif
#endif
