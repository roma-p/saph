/*******************************************************************/
/*                                                                 */
/* Copyright 2007 Adobe                                            */
/* All Rights Reserved.                                            */
/*                                                                 */
/* NOTICE:  Adobe permits you to use, modify, and distribute this  */
/* file in accordance with the terms of the Adobe license          */
/* agreement accompanying it.                                      */
/*                                                                 */
/*******************************************************************/

/*
    Skeleton.h
*/

#pragma once

#ifndef SKELETON_H
    #define SKELETON_H

typedef unsigned char u_char;
typedef unsigned short u_short;
typedef unsigned short u_int16;
typedef unsigned long u_long;
typedef short int int16;
    #define PF_TABLE_BITS 12
    #define PF_TABLE_SZ_16 4096

    #define PF_DEEP_COLOR_AWARE                                                                                        \
        1 // make sure we get 16bpc pixels;                                                                          \
            // AE_Effect.h checks for this.

    #include "AEConfig.h"

    #ifdef AE_OS_WIN
typedef unsigned short PixelType;
        #include <Windows.h>
    #endif

    #include "entry.h"
    #include "AE_Effect.h"
    #include "AE_EffectCB.h"
    #include "AE_Macros.h"
    #include "Param_Utils.h"
    #include "AE_EffectCBSuites.h"
    #include "String_Utils.h"
    #include "AE_GeneralPlug.h"
    #include "AEFX_ChannelDepthTpl.h"
    #include "AEGP_SuiteHandler.h"

    #include "Skeleton_Strings.h"

/* Versioning information */

    #define MAJOR_VERSION 1
    #define MINOR_VERSION 1
    #define BUG_VERSION 0
    #define STAGE_VERSION PF_Stage_DEVELOP
    #define BUILD_VERSION 1

/* Parameter defaults */

    #define SKELETON_GAIN_MIN 0
    #define SKELETON_GAIN_MAX 100
    #define SKELETON_GAIN_DFLT 10

enum
{
    SKELETON_INPUT = 0,
    SKELETON_GAIN,
    SKELETON_COLOR,
    SKELETON_NUM_PARAMS
};

enum
{
    GAIN_DISK_ID = 1,
    COLOR_DISK_ID,
};

typedef struct GainInfo
{
    PF_FpLong gainF;
} GainInfo, *GainInfoP, **GainInfoH;

extern "C"
{

    DllExport PF_Err EffectMain(
        PF_Cmd cmd, PF_InData* in_data, PF_OutData* out_data, PF_ParamDef* params[], PF_LayerDef* output, void* extra);
}

#endif // SKELETON_H